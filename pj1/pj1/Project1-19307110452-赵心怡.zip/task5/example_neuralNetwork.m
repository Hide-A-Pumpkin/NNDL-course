load digits.mat
tic
[n,d] = size(X);
nLabels = max(y);
yExpanded = linearInd2Binary(y,nLabels);
t = size(Xvalid,1);
t2 = size(Xtest,1);

% Standardize columns and add bias
[X,mu,sigma] = standardizeCols(X);
X = [ones(n,1) X];
d = d + 1;

% Make sure to apply the same transformation to the validation/test data
Xvalid = standardizeCols(Xvalid,mu,sigma);
Xvalid = [ones(t,1) Xvalid];
Xtest = standardizeCols(Xtest,mu,sigma);
Xtest = [ones(t2,1) Xtest];

% Choose network structure
% nHidden = [10];
nHidden = [30];
% nHidden = [10,10];
% nHidden = [10,30,30];

% Count number of parameters and initialize weights 'w'
nParams = d*nHidden(1);
for h = 2:length(nHidden)
    nParams = nParams+nHidden(h-1)*nHidden(h);
end
nParams = nParams+nHidden(end)*nLabels;
w = randn(nParams,1);

% Train with stochastic gradient
maxIter = 200000;
stepSize = 1e-2;
% stepSize = 1e-3;
% stepSize = 1e-2;
%stepSize = 1e-1;
lambda = 1e-3;
% lambda = 1e-3;
% lambda = 1e-2;
% lambda = 1e-1;
funObj = @(w,i)SoftmaxLoss(w,X(i,:),y(i,:),nHidden,nLabels,lambda);
X=[];
y=[];

for iter = 1:maxIter
    if mod(iter-1,round(maxIter/20)) == 0
        yhat = SoftmaxPredict(w,Xvalid,nHidden,nLabels);
        fprintf('Training iteration = %d, validation error = %f\n',iter-1,sum(yhat~=yvalid)/t);
        X=[X,iter];
        y=[y,sum(yhat~=yvalid)/t];
    end
    
    i = ceil(rand*n);
    [f,g] = funObj(w,i);
    w = w - stepSize*g;
end

% Evaluate test error
yhat = SoftmaxPredict(w,Xtest,nHidden,nLabels);
fprintf('Test error with final model = %f\n',sum(yhat~=ytest)/t2);


%plot error
figure(1);
plot(X,y,'-b');
title('test error');
ylabel('validation error');
xlabel('iteration times');
axis([0,200000,0,1]);
toc